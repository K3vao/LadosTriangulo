﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lados_do_triangulo.Polimorfismo
{
    public abstract class AbsPropriedades
    {
        public string Lado1 { get; set; }
        public string Lado2 { get; set; }
        public string Lado3 { get; set; }
    }


}
