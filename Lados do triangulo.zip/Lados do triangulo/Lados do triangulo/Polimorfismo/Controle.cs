﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lados_do_triangulo.Polimorfismo
{
    public class Controle : AbsPropriedades
    {


        public Controle(string lado1, string Lado2, string Lado3)
        {
            Verificar();
        }

        private Boolean Verificar()
        {
            return false;
        }
    }
}
