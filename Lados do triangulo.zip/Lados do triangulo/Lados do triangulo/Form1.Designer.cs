﻿
namespace Lados_do_triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lado1 = new System.Windows.Forms.Label();
            this.Lado2 = new System.Windows.Forms.Label();
            this.Lado3 = new System.Windows.Forms.Label();
            this.Lado1_text = new System.Windows.Forms.TextBox();
            this.Lado2_text = new System.Windows.Forms.TextBox();
            this.Lado3_text = new System.Windows.Forms.TextBox();
            this.Verificar = new System.Windows.Forms.Button();
            this.Resposta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Lado1
            // 
            this.Lado1.AutoSize = true;
            this.Lado1.Location = new System.Drawing.Point(50, 13);
            this.Lado1.Name = "Lado1";
            this.Lado1.Size = new System.Drawing.Size(40, 13);
            this.Lado1.TabIndex = 0;
            this.Lado1.Text = "Lado 1";
            // 
            // Lado2
            // 
            this.Lado2.AutoSize = true;
            this.Lado2.Location = new System.Drawing.Point(50, 72);
            this.Lado2.Name = "Lado2";
            this.Lado2.Size = new System.Drawing.Size(40, 13);
            this.Lado2.TabIndex = 1;
            this.Lado2.Text = "Lado 2";
            this.Lado2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Lado3
            // 
            this.Lado3.AutoSize = true;
            this.Lado3.Location = new System.Drawing.Point(50, 127);
            this.Lado3.Name = "Lado3";
            this.Lado3.Size = new System.Drawing.Size(40, 13);
            this.Lado3.TabIndex = 2;
            this.Lado3.Text = "Lado 3";
            // 
            // Lado1_text
            // 
            this.Lado1_text.Location = new System.Drawing.Point(53, 29);
            this.Lado1_text.Name = "Lado1_text";
            this.Lado1_text.Size = new System.Drawing.Size(163, 20);
            this.Lado1_text.TabIndex = 3;
            // 
            // Lado2_text
            // 
            this.Lado2_text.Location = new System.Drawing.Point(53, 88);
            this.Lado2_text.Name = "Lado2_text";
            this.Lado2_text.Size = new System.Drawing.Size(163, 20);
            this.Lado2_text.TabIndex = 4;
            this.Lado2_text.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Lado3_text
            // 
            this.Lado3_text.Location = new System.Drawing.Point(53, 143);
            this.Lado3_text.Name = "Lado3_text";
            this.Lado3_text.Size = new System.Drawing.Size(163, 20);
            this.Lado3_text.TabIndex = 5;
            this.Lado3_text.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // Verificar
            // 
            this.Verificar.Location = new System.Drawing.Point(53, 196);
            this.Verificar.Name = "Verificar";
            this.Verificar.Size = new System.Drawing.Size(169, 23);
            this.Verificar.TabIndex = 6;
            this.Verificar.Text = "Verificar";
            this.Verificar.UseVisualStyleBackColor = true;
            this.Verificar.Click += new System.EventHandler(this.Verificar_Click);
            // 
            // Resposta
            // 
            this.Resposta.AutoSize = true;
            this.Resposta.Location = new System.Drawing.Point(50, 241);
            this.Resposta.Name = "Resposta";
            this.Resposta.Size = new System.Drawing.Size(52, 13);
            this.Resposta.TabIndex = 7;
            this.Resposta.Text = "Resposta";
            this.Resposta.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Resposta.Click += new System.EventHandler(this.label4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 309);
            this.Controls.Add(this.Resposta);
            this.Controls.Add(this.Verificar);
            this.Controls.Add(this.Lado3_text);
            this.Controls.Add(this.Lado2_text);
            this.Controls.Add(this.Lado1_text);
            this.Controls.Add(this.Lado3);
            this.Controls.Add(this.Lado2);
            this.Controls.Add(this.Lado1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lado1;
        private System.Windows.Forms.Label Lado2;
        private System.Windows.Forms.Label Lado3;
        private System.Windows.Forms.TextBox Lado1_text;
        private System.Windows.Forms.TextBox Lado2_text;
        private System.Windows.Forms.TextBox Lado3_text;
        private System.Windows.Forms.Button Verificar;
        private System.Windows.Forms.Label Resposta;
    }
}

